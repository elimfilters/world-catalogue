# ELIMFILTERS WORLD CATALOGUE
Auto-generated structure.