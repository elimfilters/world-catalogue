const TECHNOLOGY_HOMOLOGATION_MAP = {
    'LUBE_OIL': { pref: 'EL8', tech: 'SYNTRAX�', iso: 'ISO 4548-12', desc: 'dise�ado para capturar contaminantes microsc�picos y garantizar una protecci�n hidrodin�mica superior.' },
    'AIR_SYSTEM': { pref: 'EA1', tech: 'NANOFORCE�', iso: 'ISO 5011', desc: 'fabricado para entornos de alta saturaci�n de polvo, asegurando aire ultra-puro para el turbocompresor.' },
    'FUEL_SYSTEM': { pref: 'EF9', tech: 'SYNTEPORE�', iso: 'ISO 19438', desc: 'protege los sistemas de inyecci�n contra el desgaste prematuro con eficiencia excepcional.' },
    'FUEL_SEPARATOR': { pref: 'ES9', tech: 'AQUAGUARD�', iso: 'ISO 4020', desc: 'logra una remoci�n de agua del 99.5%, previniendo la corrosi�n en los inyectores.' },
    'AIR_DRYER': { pref: 'ED4', tech: 'DRYTECH�', iso: 'ISO 12500', desc: 'garantiza aire seco y libre de contaminantes para una operaci�n segura en equipo pesado.' },
    'MARINE_FILTER': { pref: 'EM9', tech: 'MARINEGUARD�', iso: 'ISO 10088', desc: 'resistencia superior a la corrosi�n salina para proteger motores en entornos hostiles.' }
};

const KIT_TECHNOLOGY = {
    tech: 'ARMOR-SYNC�',
    desc: 'es una soluci�n de ingenier�a integral. Cada componente ha sido sincronizado para ofrecer un blindaje total y m�xima integridad operativa.'
};

const getEnrichedData = (sku) => {
    if (!sku) return null;
    const s = sku.toString().toUpperCase();
    if (s.startsWith('EK')) {
        return { tech: KIT_TECHNOLOGY.tech, full_description: 'El Kit Elimfilters� ' + s + ' bajo la arquitectura ' + KIT_TECHNOLOGY.tech + ' ' + KIT_TECHNOLOGY.desc };
    }
    const category = Object.values(TECHNOLOGY_HOMOLOGATION_MAP).find(t => s.startsWith(t.pref));
    if (category) {
        return { tech: category.tech, compliance: category.iso, full_description: 'El elemento Elimfilters� ' + s + ' con tecnolog�a ' + category.tech + ' est� ' + category.desc + ' Cumple con ' + category.iso };
    }
    return { tech: 'ELIMFILTERS�', full_description: 'Filtro de alto rendimiento Elimfilters� ' + s + ' dise�ado para servicio pesado.' };
};

module.exports = { TECHNOLOGY_HOMOLOGATION_MAP, getEnrichedData };
