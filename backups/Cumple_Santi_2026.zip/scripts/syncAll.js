const { GoogleSpreadsheet } = require('google-spreadsheet');
const { JWT } = require('google-auth-library');
require('dotenv').config();

// Extraemos la credencial de la variable de entorno
const creds = JSON.parse(process.env.GOOGLE_CREDS_JSON);

const serviceAccountAuth = new JWT({
  email: creds.client_email,
  key: creds.private_key,
  scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

async function syncAll() {
    try {
        console.log('??? Iniciando sincronizaci�n segura...');
        const doc = new GoogleSpreadsheet('1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U', serviceAccountAuth);
        await doc.loadInfo();
        console.log('? Conexi�n segura establecida con:', doc.title);
        
        // Aqu� sigue el resto de tu l�gica de sincronizaci�n...
        // El sistema ya no depende de archivos f�sicos.
    } catch (error) {
        console.error('? Error de seguridad:', error.message);
    }
}

syncAll();
